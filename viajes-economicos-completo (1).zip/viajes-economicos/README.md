# ✈️ Viajes Económicos

Página web desarrollada con React + Vite + TailwindCSS para ayudar a los viajeros a descubrir destinos económicos, consejos de ahorro y experiencias.

## Uso
```bash
npm install
npm run dev
```

## Despliegue
Recomendado: [vercel.com](https://vercel.com)
